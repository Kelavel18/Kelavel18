#!/usr/local/miniperl/miniperl
print "Content-Type: text/html\n\n";
print "<html>This is a test of /cgi/ directory of test1.ru virtual server";
