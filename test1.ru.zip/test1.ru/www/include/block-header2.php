﻿<div id="block-header">
    <div id="header-top-block">
        <ul id="header-top-menu">
            <li><a href="index.php">Пользователи</a></li>
            <li><a href="insert.php">Добавление нового пользователя</a></li>
            <li><img src="images/imagem1.png"</a></li>
	    <li><img src="images/imagem2.png"</a></li>
	</ul>
    </div>
</div>